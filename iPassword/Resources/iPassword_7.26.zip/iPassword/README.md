# iPassword
This is a simple tool for storing their passwords, so as not to have too many passwords and forget some of them.
