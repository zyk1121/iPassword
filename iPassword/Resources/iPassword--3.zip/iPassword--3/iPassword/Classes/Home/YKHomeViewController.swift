//
//  YKHomeViewController.swift
//  iPassword
//
//  Created by 张元科 on 2018/7/1.
//  Copyright © 2018年 SDJG. All rights reserved.
//

import UIKit
import LocalAuthentication
import SnapKit
import SDWebImage
import RxCocoa
import RxSwift

class YKHomeViewController: YKBaseViewController {

    private let mainView:YKQuestionLibMainView = YKQuestionLibMainView()
    private let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
//        hideNavLeftButton()
        setupUI()
//        setLeftNavButton()
        updateViewConstraints()
        YKPasswordSettingConfig.config.isShowPassVC = true
    }

    func setupUI() {
        setTitle(title: "密码助手")
        setRightNavButton()
        self.view.addSubview(mainView)
        mainView.parentVC = self
        NotificationCenter.default.rx.notification(Notification.Name.init("kYKReloadPasswordData")).subscribe {[weak self] (event) in
            self?.loadData()
        }.disposed(by: disposeBag)
    }
    
    override func updateViewConstraints() {
        super.updateViewConstraints()
        
        mainView.snp.remakeConstraints { (make) in
            make.edges.equalTo(self.view)
        }
    }
    
    func loadData()
    {
        self.mainView.setupEntity()
    }
    
//    func setLeftNavButton()
//    {
//        let rightButton = UIButton(type: .custom)
//        rightButton.setTitle("备份", for: .normal)
//        rightButton.setTitleColor(YKMainColor, for: .normal)
//        rightButton.addTarget(self, action: #selector(leftNavButtonClick), for: .touchUpInside)
//        let rightItem = UIBarButtonItem(customView: rightButton)
//        self.navigationItem.leftBarButtonItem = rightItem
//    }
    func setRightNavButton() {
        let rightButton = UIButton(type: .custom)
        rightButton.setTitle("添加", for: .normal)
        rightButton.setTitleColor(YKMainColor, for: .normal)
        rightButton.addTarget(self, action: #selector(rightNavButtonClick), for: .touchUpInside)
        let rightItem = UIBarButtonItem(customView: rightButton)
        
        
        let rightButton2 = UIButton(type: .custom)
        rightButton2.setTitle("备份", for: .normal)
        rightButton2.setTitleColor(YKMainColor, for: .normal)
        rightButton2.addTarget(self, action: #selector(leftNavButtonClick), for: .touchUpInside)
        let rightItem2 = UIBarButtonItem(customView: rightButton2)
        
        self.navigationItem.rightBarButtonItems = [rightItem,rightItem2]
    }
    
    @objc func rightNavButtonClick()
    {
        let vc = YKAddPasswordVC()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func leftNavButtonClick()
    {
        let vc = YKPassSettingViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let hasSetPass = UserDefaults.standard.integer(forKey: "kYKHasSetPassword")
        if hasSetPass != 1 {
            YKPasswordSettingConfig.config.firstCheck()
        } else {
            // 验证密码
            YKPasswordSettingConfig.config.checkNeedVerify()
        }
        self.loadData()
    }
    
    deinit {
        YKPasswordSettingConfig.config.isShowPassVC = false
        YKPasswordSettingConfig.config.backgroundMode = true
    }
}

