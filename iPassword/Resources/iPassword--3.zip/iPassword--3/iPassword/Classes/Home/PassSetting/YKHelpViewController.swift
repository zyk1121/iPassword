//
//  YKHelpViewController.swift
//  iPassword
//
//  Created by 张元科 on 2018/8/4.
//  Copyright © 2018年 SDJG. All rights reserved.
//

import UIKit

class YKHelpViewController: YKBaseViewController {

    private let webView = UIWebView()
    override func viewDidLoad() {
        super.viewDidLoad()
        setTitle(title: "帮助")
        setupUI()
    }
    func setupUI()
    {
//        UIWebView *myWebView = [[UIWebView alloc] init];
//        myWebView.backgroundColor = [UIColor whiteColor];
//        NSURL *filePath = [NSURL URLWithString:[[NSBundle mainBundle] pathForResource:@"myHome" ofType:@"pdf"]];
//        NSURLRequest *request = [NSURLRequest requestWithURL: filePath];
//        [myWebView loadRequest:request];
//        //使文档的显示范围适合UIWebView的bounds
//        [myWebView setScalesPageToFit:YES];
        

        webView.frame = self.view.bounds
        self.view.addSubview(webView)
        let filePath = URL(fileURLWithPath: Bundle.main.path(forResource: "help", ofType: "pdf")!)
        let request = URLRequest(url: filePath)
        webView.loadRequest(request)
        webView.scalesPageToFit = true
        
        setRightNavButton()
    }
    
    func setRightNavButton() {
        let rightButton = UIButton(type: .custom)
        rightButton.setTitle("下载", for: .normal)
        rightButton.setTitleColor(YKMainColor, for: .normal)
        rightButton.addTarget(self, action: #selector(rightNavButtonClick), for: .touchUpInside)
        let rightItem = UIBarButtonItem(customView: rightButton)
        
        self.navigationItem.rightBarButtonItem = rightItem
    }
    
    @objc func rightNavButtonClick()
    {
        if let ipstr = UserDefaults.standard.value(forKey: "ipAddress") as? String {
            let srvStr = "http://\(ipstr):9088/help.pdf"
            UIPasteboard.general.string = srvStr
            CBToast.showToastAction(message: "帮助文档下载链接已复制到剪贴板")
        }
    }
}
